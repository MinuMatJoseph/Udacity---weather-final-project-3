Node.js is to install it on your computer
Install node packages npm install express, npm install body-parser, npm install cors in the folder
Create API credentials on OpenWeatherMap.com
By ZIP code-the search works for USA as a default.